// Ghost Mode - Multi-Account & Session Switcher
// Background Service Worker (Manifest V3)
// Made by MasoomDev

function getRootDomain(hostname) {
  if (!hostname) return "";
  if (hostname === "localhost" || /^\d+\.\d+\.\d+\.\d+$/.test(hostname)) {
    return hostname;
  }
  const parts = hostname.split(".");
  if (parts.length <= 2) return hostname;

  const twoPartTLDs = ["co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "co.jp", "co.in", "com.pk", "com.br"];
  const lastTwo = parts.slice(-2).join(".");
  if (twoPartTLDs.includes(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join(".");
  }
  return lastTwo;
}

async function fetchDomainCookies(rootDomain) {
  const allCookies = await chrome.cookies.getAll({});
  return allCookies.filter((c) => {
    const cleanDomain = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
    return cleanDomain === rootDomain || cleanDomain.endsWith("." + rootDomain);
  });
}

async function clearDomainCookies(rootDomain) {
  const cookies = await fetchDomainCookies(rootDomain);
  for (const c of cookies) {
    const cleanDomain = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
    const protocol = c.secure ? "https://" : "http://";
    const url = protocol + cleanDomain + c.path;
    try {
      await chrome.cookies.remove({
        url,
        name: c.name,
        storeId: c.storeId
      });
    } catch (e) {}
  }
}

// Normalize sameSite across different cookie extensions (EditThisCookie, Cookie-Editor, J2TEAM, etc.)
function normalizeSameSite(raw) {
  if (!raw) return "unspecified";
  const val = String(raw).toLowerCase().trim();
  if (val === "no_restriction" || val === "none") return "no_restriction";
  if (val === "lax") return "lax";
  if (val === "strict") return "strict";
  return "unspecified";
}

// Normalize any external JSON cookie object into Chrome's standard format
// extendDays: if provided (>0), push out the expirationDate of any already-persistent
// cookie (one that has a real expirationDate) to "now + extendDays". This only affects
// how long the BROWSER keeps the cookie around — it cannot override how long the
// website's own server-side session stays valid.
function normalizeImportedCookies(rawCookies, fallbackRootDomain, extendDays = 0) {
  if (!Array.isArray(rawCookies)) return [];

  const normalized = [];
  for (const item of rawCookies) {
    if (!item || typeof item !== "object" || !item.name) continue;

    let domain = (item.domain || fallbackRootDomain || "").trim();
    if (!domain) continue;

    // Filter out unrelated domains if user uploaded a multi-site dump, keeping matching rootDomain
    const cleanDomain = domain.startsWith(".") ? domain.slice(1) : domain;
    if (fallbackRootDomain && cleanDomain !== fallbackRootDomain && !cleanDomain.endsWith("." + fallbackRootDomain)) {
      continue;
    }

    const hostOnly = typeof item.hostOnly === "boolean" ? item.hostOnly : !domain.startsWith(".");
    let exp = item.expirationDate || item.expires || item.expiry || null;
    const isSession = typeof item.session === "boolean" ? item.session : !exp;

    // Only extend cookies that were already persistent (had their own expirationDate).
    // We don't fabricate expiry on pure session cookies — that changes their semantics
    // and most auth cookies that are session-only are meant to die with the browser.
    if (!isSession && exp && extendDays > 0) {
      const extendedTs = Math.floor(Date.now() / 1000) + extendDays * 86400;
      if (extendedTs > Number(exp)) {
        exp = extendedTs;
      }
    }

    normalized.push({
      name: String(item.name),
      value: item.value !== undefined && item.value !== null ? String(item.value) : "",
      domain: domain,
      path: item.path || "/",
      secure: Boolean(item.secure),
      httpOnly: Boolean(item.httpOnly),
      sameSite: normalizeSameSite(item.sameSite),
      hostOnly: hostOnly,
      session: isSession,
      expirationDate: exp ? Number(exp) : undefined
    });
  }
  return normalized;
}

async function restoreDomainCookies(cookies) {
  for (const c of cookies) {
    const cleanDomain = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
    const protocol = c.secure ? "https://" : "http://";
    const url = protocol + cleanDomain + (c.path || "/");

    const details = {
      url,
      name: c.name,
      value: c.value,
      path: c.path || "/",
      secure: Boolean(c.secure),
      httpOnly: Boolean(c.httpOnly),
      sameSite: normalizeSameSite(c.sameSite)
    };

    if (c.storeId) {
      details.storeId = c.storeId;
    }

    if (!c.hostOnly) {
      details.domain = c.domain.startsWith(".") ? c.domain : "." + c.domain;
    }

    if (!c.session && c.expirationDate) {
      // Ensure expiration is in the future if a slightly stale numeric timestamp is imported
      details.expirationDate = Number(c.expirationDate);
    }

    try {
      await chrome.cookies.set(details);
    } catch (e) {}
  }
}

async function captureWebStorage(tabId) {
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const ls = {};
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          ls[k] = localStorage.getItem(k);
        }
        const ss = {};
        for (let i = 0; i < sessionStorage.length; i++) {
          const k = sessionStorage.key(i);
          ss[k] = sessionStorage.getItem(k);
        }
        return { localStorage: ls, sessionStorage: ss };
      }
    });
    return (res && res[0] && res[0].result) || { localStorage: {}, sessionStorage: {} };
  } catch (e) {
    return { localStorage: {}, sessionStorage: {} };
  }
}

async function applyWebStorage(tabId, storageData) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (data) => {
        localStorage.clear();
        sessionStorage.clear();
        if (data && data.localStorage) {
          for (const [k, v] of Object.entries(data.localStorage)) {
            localStorage.setItem(k, v);
          }
        }
        if (data && data.sessionStorage) {
          for (const [k, v] of Object.entries(data.sessionStorage)) {
            sessionStorage.setItem(k, v);
          }
        }
      },
      args: [storageData || { localStorage: {}, sessionStorage: {} }]
    });
  } catch (e) {}
}

async function updateTabBadge(tabId, label, color = "#7c3aed") {
  try {
    const shortTag = label ? label.slice(0, 4).toUpperCase() : "";
    await chrome.action.setBadgeText({ tabId, text: shortTag });
    await chrome.action.setBadgeBackgroundColor({ tabId, color });
  } catch (e) {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "GET_DOMAIN_DATA") {
        const urlObj = new URL(msg.url);
        const rootDomain = getRootDomain(urlObj.hostname);
        const store = await chrome.storage.local.get(["profiles", "activeProfiles"]);
        const profiles = (store.profiles && store.profiles[rootDomain]) || [];
        const activeId = (store.activeProfiles && store.activeProfiles[rootDomain]) || null;
        const currentCookies = await fetchDomainCookies(rootDomain);

        sendResponse({
          ok: true,
          rootDomain,
          profiles,
          activeId,
          cookieCount: currentCookies.length
        });
      }

      else if (msg.type === "SAVE_PROFILE") {
        const { tabId, url, name, color, includeStorage, existingId } = msg;
        const urlObj = new URL(url);
        const rootDomain = getRootDomain(urlObj.hostname);

        const cookies = await fetchDomainCookies(rootDomain);
        const webStorage = includeStorage ? await captureWebStorage(tabId) : { localStorage: {}, sessionStorage: {} };

        const store = await chrome.storage.local.get(["profiles", "activeProfiles"]);
        const allProfiles = store.profiles || {};
        const activeProfiles = store.activeProfiles || {};
        const domainProfiles = allProfiles[rootDomain] || [];

        const profileId = existingId || ("prof_" + Date.now());
        const newProfile = {
          id: profileId,
          name: name.trim(),
          color: color || "#7c3aed",
          cookies,
          webStorage,
          includeStorage: Boolean(includeStorage),
          updatedAt: Date.now()
        };

        const idx = domainProfiles.findIndex((p) => p.id === profileId);
        if (idx >= 0) {
          domainProfiles[idx] = newProfile;
        } else {
          domainProfiles.push(newProfile);
        }

        allProfiles[rootDomain] = domainProfiles;
        activeProfiles[rootDomain] = profileId;

        await chrome.storage.local.set({ profiles: allProfiles, activeProfiles });
        await updateTabBadge(tabId, newProfile.name, newProfile.color);

        sendResponse({ ok: true, profile: newProfile });
      }

      else if (msg.type === "IMPORT_JSON_PROFILE") {
        const { tabId, url, name, color, rawJsonData, activateNow, extendDays } = msg;
        const urlObj = new URL(url);
        const rootDomain = getRootDomain(urlObj.hostname);
        const safeExtendDays = Math.max(0, Math.min(Number(extendDays) || 0, 3650)); // hard cap 10 years

        // Support raw array [...] OR wrapped object { cookies: [...], webStorage: {...} }
        let rawCookies = [];
        let webStorage = { localStorage: {}, sessionStorage: {} };

        if (Array.isArray(rawJsonData)) {
          rawCookies = rawJsonData;
        } else if (rawJsonData && Array.isArray(rawJsonData.cookies)) {
          rawCookies = rawJsonData.cookies;
          if (rawJsonData.webStorage) {
            webStorage = rawJsonData.webStorage;
          }
        } else {
          sendResponse({ ok: false, error: "Invalid JSON format. Expected a cookie array or { cookies: [...] }." });
          return;
        }

        let normalizedCookies = normalizeImportedCookies(rawCookies, rootDomain, safeExtendDays);

        // If no cookies matched rootDomain specifically, check if JSON belongs to another single domain and import all valid cookies
        if (normalizedCookies.length === 0) {
          normalizedCookies = normalizeImportedCookies(rawCookies, "", safeExtendDays);
        }

        if (normalizedCookies.length === 0) {
          sendResponse({ ok: false, error: "No valid cookies found inside JSON." });
          return;
        }

        const store = await chrome.storage.local.get(["profiles", "activeProfiles"]);
        const allProfiles = store.profiles || {};
        const activeProfiles = store.activeProfiles || {};
        const domainProfiles = allProfiles[rootDomain] || [];

        const profileId = "prof_" + Date.now();
        const importedProfile = {
          id: profileId,
          name: name.trim(),
          color: color || "#2563eb",
          cookies: normalizedCookies,
          webStorage,
          includeStorage: Boolean(webStorage && (Object.keys(webStorage.localStorage || {}).length > 0)),
          imported: true,
          updatedAt: Date.now()
        };

        domainProfiles.push(importedProfile);
        allProfiles[rootDomain] = domainProfiles;

        if (activateNow) {
          await clearDomainCookies(rootDomain);
          await restoreDomainCookies(normalizedCookies);
          await applyWebStorage(tabId, webStorage);
          activeProfiles[rootDomain] = profileId;
          await chrome.storage.local.set({ profiles: allProfiles, activeProfiles });
          await updateTabBadge(tabId, importedProfile.name, importedProfile.color);
          await chrome.tabs.reload(tabId);
        } else {
          await chrome.storage.local.set({ profiles: allProfiles });
        }

        sendResponse({ ok: true, count: normalizedCookies.length, profile: importedProfile });
      }

      else if (msg.type === "SWITCH_PROFILE") {
        const { tabId, url, profileId } = msg;
        const urlObj = new URL(url);
        const rootDomain = getRootDomain(urlObj.hostname);

        const store = await chrome.storage.local.get(["profiles", "activeProfiles"]);
        const allProfiles = store.profiles || {};
        const activeProfiles = store.activeProfiles || {};
        const domainProfiles = allProfiles[rootDomain] || [];

        const target = domainProfiles.find((p) => p.id === profileId);
        if (!target) {
          sendResponse({ ok: false, error: "Profile not found" });
          return;
        }

        await clearDomainCookies(rootDomain);
        await restoreDomainCookies(target.cookies || []);
        await applyWebStorage(tabId, target.webStorage);

        activeProfiles[rootDomain] = target.id;
        await chrome.storage.local.set({ activeProfiles });
        await updateTabBadge(tabId, target.name, target.color);

        await chrome.tabs.reload(tabId);
        sendResponse({ ok: true });
      }

      else if (msg.type === "GHOST_FRESH_SESSION") {
        const { tabId, url } = msg;
        const urlObj = new URL(url);
        const rootDomain = getRootDomain(urlObj.hostname);

        await clearDomainCookies(rootDomain);
        await applyWebStorage(tabId, { localStorage: {}, sessionStorage: {} });

        const store = await chrome.storage.local.get("activeProfiles");
        const activeProfiles = store.activeProfiles || {};
        delete activeProfiles[rootDomain];
        await chrome.storage.local.set({ activeProfiles });

        await updateTabBadge(tabId, "GHST", "#10b981");
        await chrome.tabs.reload(tabId);
        sendResponse({ ok: true });
      }

      else if (msg.type === "DELETE_PROFILE") {
        const { url, profileId } = msg;
        const urlObj = new URL(url);
        const rootDomain = getRootDomain(urlObj.hostname);

        const store = await chrome.storage.local.get(["profiles", "activeProfiles"]);
        const allProfiles = store.profiles || {};
        const activeProfiles = store.activeProfiles || {};

        if (allProfiles[rootDomain]) {
          allProfiles[rootDomain] = allProfiles[rootDomain].filter((p) => p.id !== profileId);
        }
        if (activeProfiles[rootDomain] === profileId) {
          delete activeProfiles[rootDomain];
        }

        await chrome.storage.local.set({ profiles: allProfiles, activeProfiles });
        sendResponse({ ok: true });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message });
    }
  })();

  return true;
});
