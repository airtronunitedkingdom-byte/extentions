// Ghost Mode - Multi-Account & Session Switcher
// Popup Controller (with JSON Cookie Import & Export)
// Made by MasoomDev

document.addEventListener("DOMContentLoaded", async () => {
  let activeTab = null;
  let selectedColor = "#7c3aed";
  let loadedFileJsonText = "";

  const domainLabel = document.getElementById("domainLabel");
  const cookieCountBadge = document.getElementById("cookieCountBadge");
  const unsupportedBox = document.getElementById("unsupportedBox");
  const mainWorkspace = document.getElementById("mainWorkspace");

  const profilesList = document.getElementById("profilesList");
  const profileCountTag = document.getElementById("profileCountTag");
  const profileNameInput = document.getElementById("profileNameInput");
  const includeStorageCheck = document.getElementById("includeStorageCheck");
  const saveSessionBtn = document.getElementById("saveSessionBtn");
  const newGhostBtn = document.getElementById("newGhostBtn");
  const colorDots = document.querySelectorAll(".color-dot");
  const toastMsg = document.getElementById("toastMsg");

  // Tabs & Import Controls
  const tabCapture = document.getElementById("tabCapture");
  const tabImport = document.getElementById("tabImport");
  const capturePanel = document.getElementById("capturePanel");
  const importPanel = document.getElementById("importPanel");

  const importNameInput = document.getElementById("importNameInput");
  const jsonFileInput = document.getElementById("jsonFileInput");
  const fileNameLabel = document.getElementById("fileNameLabel");
  const jsonTextInput = document.getElementById("jsonTextInput");
  const activateOnImportCheck = document.getElementById("activateOnImportCheck");
  const extendDaysInput = document.getElementById("extendDaysInput");
  const importJsonBtn = document.getElementById("importJsonBtn");

  function showToast(text, isError = false) {
    toastMsg.textContent = text;
    toastMsg.classList.toggle("error", isError);
    toastMsg.classList.remove("hidden");
    setTimeout(() => {
      toastMsg.classList.add("hidden");
    }, 3000);
  }

  // Tab switching
  tabCapture.addEventListener("click", () => {
    tabCapture.classList.add("active");
    tabImport.classList.remove("active");
    capturePanel.classList.remove("hidden");
    importPanel.classList.add("hidden");
  });

  tabImport.addEventListener("click", () => {
    tabImport.classList.add("active");
    tabCapture.classList.remove("active");
    importPanel.classList.remove("hidden");
    capturePanel.classList.add("hidden");
  });

  // Color selector
  colorDots.forEach((dot) => {
    dot.addEventListener("click", () => {
      colorDots.forEach((d) => d.classList.remove("active"));
      dot.classList.add("active");
      selectedColor = dot.dataset.color;
    });
  });

  // Handle .json file upload
  jsonFileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    fileNameLabel.textContent = file.name;
    if (!importNameInput.value.trim()) {
      importNameInput.value = file.name.replace(/\.json$/i, "");
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      loadedFileJsonText = ev.target.result || "";
      jsonTextInput.value = loadedFileJsonText;
    };
    reader.onerror = () => {
      showToast("Failed to read JSON file.", true);
    };
    reader.readAsText(file);
  });

  // Get current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tab;

  if (!activeTab || !activeTab.url || !activeTab.url.startsWith("http")) {
    domainLabel.textContent = "Unsupported page";
    unsupportedBox.classList.remove("hidden");
    mainWorkspace.classList.add("hidden");
    return;
  }

  function formatTimeAgo(ts) {
    const diffSec = Math.floor((Date.now() - ts) / 1000);
    if (diffSec < 60) return "Just now";
    if (diffSec < 3600) return Math.floor(diffSec / 60) + "m ago";
    if (diffSec < 86400) return Math.floor(diffSec / 3600) + "h ago";
    return Math.floor(diffSec / 86400) + "d ago";
  }

  function downloadJsonFile(filename, dataObj) {
    const blob = new Blob([JSON.stringify(dataObj, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function renderProfiles(profiles, activeId, rootDomain) {
    profileCountTag.textContent = profiles.length;
    profilesList.innerHTML = "";

    if (profiles.length === 0) {
      profilesList.innerHTML = `
        <div class="empty-state">
          No saved sessions for this site yet.<br>
          Capture your active login or click <strong>Import JSON Cookies</strong> below.
        </div>
      `;
      return;
    }

    profiles.forEach((prof) => {
      const isCurrent = prof.id === activeId;
      const card = document.createElement("div");
      card.className = "profile-card" + (isCurrent ? " active" : "");

      const cookieLen = prof.cookies ? prof.cookies.length : 0;

      card.innerHTML = `
        <div class="profile-info">
          <span class="avatar-dot" style="background:${prof.color || "#7c3aed"};"></span>
          <div class="profile-meta">
            <div class="profile-name">
              <span>${escapeHtml(prof.name)}</span>
              ${isCurrent ? '<span class="active-tag">Active</span>' : ""}
              ${prof.imported ? '<span class="imported-tag">JSON</span>' : ""}
            </div>
            <div class="profile-sub">${cookieLen} cookies • ${formatTimeAgo(prof.updatedAt)}</div>
          </div>
        </div>
        <div class="profile-actions">
          <button class="btn-mini btn-switch" data-id="${prof.id}" title="Switch to this account">Switch</button>
          <button class="btn-mini btn-icon btn-export" data-id="${prof.id}" title="Export cookies as JSON">⤓</button>
          <button class="btn-mini btn-icon btn-sync" data-id="${prof.id}" title="Overwrite with current browser cookies">↻</button>
          <button class="btn-mini btn-del" data-id="${prof.id}" title="Delete session">✕</button>
        </div>
      `;

      profilesList.appendChild(card);
    });

    // Switch handler
    profilesList.querySelectorAll(".btn-switch").forEach((btn) => {
      btn.addEventListener("click", () => {
        const profileId = btn.dataset.id;
        btn.textContent = "...";
        chrome.runtime.sendMessage(
          { type: "SWITCH_PROFILE", tabId: activeTab.id, url: activeTab.url, profileId },
          (res) => {
            if (res && res.ok) {
              window.close();
            } else {
              showToast("Failed to switch session.", true);
            }
          }
        );
      });
    });

    // Export JSON handler
    profilesList.querySelectorAll(".btn-export").forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetProf = profiles.find((p) => p.id === btn.dataset.id);
        if (!targetProf) return;
        const safeName = targetProf.name.replace(/[^a-z0-9_-]/gi, "_");
        downloadJsonFile(`${rootDomain}_${safeName}_cookies.json`, targetProf.cookies || []);
        showToast(`Exported "${targetProf.name}" JSON!`);
      });
    });

    // Sync/Overwrite handler
    profilesList.querySelectorAll(".btn-sync").forEach((btn) => {
      btn.addEventListener("click", () => {
        const existingId = btn.dataset.id;
        const targetProf = profiles.find((p) => p.id === existingId);
        if (!targetProf) return;

        chrome.runtime.sendMessage(
          {
            type: "SAVE_PROFILE",
            tabId: activeTab.id,
            url: activeTab.url,
            name: targetProf.name,
            color: targetProf.color,
            includeStorage: targetProf.includeStorage,
            existingId
          },
          (res) => {
            if (res && res.ok) {
              showToast(`Updated "${targetProf.name}"!`);
              loadDomainData();
            }
          }
        );
      });
    });

    // Delete handler
    profilesList.querySelectorAll(".btn-del").forEach((btn) => {
      btn.addEventListener("click", () => {
        const profileId = btn.dataset.id;
        chrome.runtime.sendMessage(
          { type: "DELETE_PROFILE", url: activeTab.url, profileId },
          (res) => {
            if (res && res.ok) {
              showToast("Session deleted.");
              loadDomainData();
            }
          }
        );
      });
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function loadDomainData() {
    chrome.runtime.sendMessage({ type: "GET_DOMAIN_DATA", url: activeTab.url }, (res) => {
      if (res && res.ok) {
        domainLabel.textContent = res.rootDomain;
        cookieCountBadge.textContent = `${res.cookieCount} cookie${res.cookieCount === 1 ? "" : "s"}`;
        renderProfiles(res.profiles, res.activeId, res.rootDomain);
      }
    });
  }

  // Save current live session
  saveSessionBtn.addEventListener("click", () => {
    const rawName = profileNameInput.value.trim();
    const name = rawName || `Account ${Number(profileCountTag.textContent) + 1}`;

    chrome.runtime.sendMessage(
      {
        type: "SAVE_PROFILE",
        tabId: activeTab.id,
        url: activeTab.url,
        name,
        color: selectedColor,
        includeStorage: includeStorageCheck.checked
      },
      (res) => {
        if (res && res.ok) {
          profileNameInput.value = "";
          showToast(`Saved "${name}"!`);
          loadDomainData();
        } else {
          showToast("Could not capture session.", true);
        }
      }
    );
  });

  // Import JSON Cookies (from uploaded file or pasted text)
  importJsonBtn.addEventListener("click", () => {
    const rawText = jsonTextInput.value.trim();
    if (!rawText) {
      showToast("Please select a .json file or paste JSON cookies.", true);
      return;
    }

    let parsedJson;
    try {
      parsedJson = JSON.parse(rawText);
    } catch (err) {
      showToast("Invalid JSON syntax. Check your file or text.", true);
      return;
    }

    const rawName = importNameInput.value.trim();
    const name = rawName || `Imported ${Number(profileCountTag.textContent) + 1}`;
    const activateNow = activateOnImportCheck.checked;
    const extendDays = Math.max(0, Math.min(Number(extendDaysInput.value) || 0, 3650));

    chrome.runtime.sendMessage(
      {
        type: "IMPORT_JSON_PROFILE",
        tabId: activeTab.id,
        url: activeTab.url,
        name,
        color: "#2563eb",
        rawJsonData: parsedJson,
        activateNow,
        extendDays
      },
      (res) => {
        if (res && res.ok) {
          if (activateNow) {
            window.close();
          } else {
            importNameInput.value = "";
            jsonTextInput.value = "";
            fileNameLabel.textContent = "No file selected";
            showToast(`Imported ${res.count} cookies as "${name}"!`);
            tabCapture.click();
            loadDomainData();
          }
        } else {
          showToast(res ? res.error : "Import failed.", true);
        }
      }
    );
  });

  // Fresh Ghost Session
  newGhostBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage(
      { type: "GHOST_FRESH_SESSION", tabId: activeTab.id, url: activeTab.url },
      (res) => {
        if (res && res.ok) {
          window.close();
        }
      }
    );
  });

  loadDomainData();
});
