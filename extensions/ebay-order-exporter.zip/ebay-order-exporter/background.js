const ORDER_RE = /^\d{2}-\d{5}-\d{5}$/;
const ORDERS_URL_PREFIX = 'https://www.ebay.co.uk/sh/ord';
const HEADER = [
  'Sales record number', 'Order number', 'Post to name', 'Item title',
  'Quantity', 'Sell Price', 'Buying', 'Order Earning', 'Sale date'
];

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'run') {
    runJob(msg).catch((err) => setStatus(`Error: ${err.message}`, true));
    sendResponse({ ok: true });
  }
  return false;
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function setStatus(text, done = false) {
  await chrome.storage.local.set({ status: { text, done, at: Date.now() } });
}

async function runJob({ orderNumber, from, to }) {
  const target = (orderNumber || '').trim();
  if (!ORDER_RE.test(target)) {
    throw new Error('Order number format galat hai (jaise 02-15484-10162).');
  }

  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab || !activeTab.url || !activeTab.url.startsWith(ORDERS_URL_PREFIX)) {
    throw new Error('Pehle eBay Seller Hub ka Orders page kholen (ebay.co.uk/sh/ord).');
  }

  await setStatus('Orders list parh raha hoon...');
  const res = await chrome.scripting.executeScript({
    target: { tabId: activeTab.id },
    func: readOrderList
  });
  const list = (res && res[0] && res[0].result) || [];
  if (!list.length) throw new Error('Is page par koi order nahi mila.');

  // List latest se purani ki taraf sorted hoti hai: latest se lekar target tak
  const idx = list.findIndex((r) => r.orderNumber === target);
  if (idx < 0) {
    throw new Error(`${target} is page par nahi mila. Orders list ka woh page kholen jis par ye order ho.`);
  }
  const slice = list.slice(0, idx + 1);

  const rows = [];
  const skipped = [];
  for (let i = 0; i < slice.length; i++) {
    const item = slice[i];
    await setStatus(`Order ${i + 1} / ${slice.length} parh raha hoon: ${item.orderNumber}`);
    const detail = await readDetail(item);
    if (!detail) {
      skipped.push(item.orderNumber);
      continue;
    }
    if (inRange(detail.soldDate, from, to)) rows.push(detail);
  }

  if (!rows.length) throw new Error('Is date range mein koi order nahi mila.');

  const csv = buildCsv(rows);
  const today = new Date().toISOString().slice(0, 10);
  // Base64 data URL: UTF-8 BOM aur special characters (’ etc.) Excel mein sahi khulte hain
  const b64 = btoa(unescape(encodeURIComponent(csv)));
  await chrome.downloads.download({
    url: 'data:text/csv;charset=utf-8;base64,' + b64,
    filename: `ebay_orders_${target}_${today}.csv`,
    saveAs: true
  });
  const skipNote = skipped.length ? ` Skip hue (detail load nahi hui): ${skipped.join(', ')}` : '';
  await setStatus(`Done: ${rows.length} order CSV mein export ho gaye.${skipNote}`, true);
}

function detailUrl(item) {
  const srn = item.srn ? `&srn=${item.srn}` : '';
  return `https://www.ebay.co.uk/mesh/ord/details?mode=SH${srn}` +
    `&orderid=${item.orderNumber}&source=Orders&ru=${encodeURIComponent(ORDERS_URL_PREFIX)}`;
}

function waitForLoad(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, 30000);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') done();
    }
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function readDetail(item) {
  const tab = await chrome.tabs.create({ url: detailUrl(item), active: false });
  try {
    await waitForLoad(tab.id);
    for (let k = 0; k < 30; k++) {
      try {
        const res = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: readDetailPage
        });
        const data = res && res[0] && res[0].result;
        if (data) {
          data.orderNumber = data.orderNumber || item.orderNumber;
          data.srn = data.srn || item.srn;
          return data;
        }
      } catch (_) { /* page abhi ready nahi */ }
      await sleep(1000);
    }
    return null;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

function inRange(soldDate, from, to) {
  if (!from && !to) return true;
  const d = new Date(`${soldDate} UTC`);
  if (isNaN(d)) return false;
  if (from && d < new Date(`${from}T00:00:00Z`)) return false;
  if (to && d > new Date(`${to}T23:59:59Z`)) return false;
  return true;
}

function fmtDate(s) {
  const d = new Date(`${s} UTC`);
  if (isNaN(d)) return s || '';
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  return `${dd}/${mm}/${d.getUTCFullYear()}`;
}

function buildCsv(rows) {
  const esc = (v) => {
    const s = v == null ? '' : String(v);
    return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [HEADER.join(',')];
  for (const r of rows) {
    lines.push([
      r.srn, r.orderNumber, r.postName, r.title, r.qty,
      r.sellPrice, '', r.earning, fmtDate(r.soldDate)
    ].map(esc).join(','));
  }
  return '﻿' + lines.join('\r\n');
}

// ----- Ye functions tab ke andar (page context) chalte hain -----

// Orders list se order number + sales record (srn) nikalta hai, list ke order mein
function readOrderList() {
  const seen = new Set();
  const out = [];
  for (const a of document.querySelectorAll('a')) {
    const t = (a.textContent || '').trim();
    if (!/^\d{2}-\d{5}-\d{5}$/.test(t) || seen.has(t)) continue;
    seen.add(t);
    const m = (a.href || '').match(/srn=(\d+)/);
    out.push({ orderNumber: t, srn: m ? m[1] : '' });
  }
  return out;
}

// Order details page se values nikalta hai
function readDetailPage() {
  const flat = (document.body.textContent || '').replace(/\s+/g, ' ');
  const dlg = [...document.querySelectorAll('[role=dialog]')]
    .find((d) => /Order detail/.test(d.textContent));
  const dt = dlg ? dlg.textContent.replace(/\s+/g, ' ') : '';
  const pick = (s, re) => {
    const m = s.match(re);
    return m ? m[1].trim() : '';
  };

  const earning = pick(dt, /Order Earning\s*(-?[\d.]+)/);
  const buyerPaid = pick(dt, /Buyer Paid\s*([\d.]+)/);
  const orderNumber = pick(dt, /Order ID\s*([\d-]+)/);
  const soldDate = pick(dt, /Sold Date\s*(\d{1,2} \w{3} \d{4})/);
  // Dialog pehle placeholder (0.00) dikhata hai; sab fields aane tak wait karein
  if (!earning || !buyerPaid || !soldDate || !orderNumber) return null;
  const srn = pick(flat, /Sales record no\.\s*(\d+)/);

  const lines = (document.body.innerText || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const after = (label) => {
    const i = lines.indexOf(label);
    return i >= 0 ? (lines[i + 1] || '') : '';
  };
  const qIdx = lines.indexOf('Quantity');
  const qtyMatch = qIdx >= 0 ? lines.slice(qIdx, qIdx + 4).join(' ').match(/(\d+)\s*\(/) : null;

  return {
    orderNumber,
    srn,
    postName: after('Post to'),
    title: after('Item'),
    qty: qtyMatch ? qtyMatch[1] : '',
    sellPrice: buyerPaid,
    earning,
    soldDate
  };
}
