const $ = (id) => document.getElementById(id);
const ORDER_RE = /^\d{2}-\d{5}-\d{5}$/;

function showStatus(s) {
  const text = s.text || '';
  $('status').textContent = text;
  $('status').className = s.done ? 'done' : '';
  $('start').disabled = !s.done && !/^Error/.test(text);
}

// Pichli values aur chal rahe job ka status restore karein
chrome.storage.local.get(['inputs', 'status']).then(({ inputs, status }) => {
  if (inputs) {
    $('orderNumber').value = inputs.orderNumber || '';
    $('from').value = inputs.from || '';
    $('to').value = inputs.to || '';
  }
  if (status) showStatus(status);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.status && changes.status.newValue) {
    showStatus(changes.status.newValue);
  }
});

$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const orderNumber = $('orderNumber').value.trim();
  const from = $('from').value;
  const to = $('to').value;

  if (!ORDER_RE.test(orderNumber)) {
    showStatus({ text: 'Error: Order number format galat hai (jaise 02-15484-10162).', done: true });
    return;
  }
  if (from && to && from > to) {
    showStatus({ text: 'Error: From date To date se bari nahi honi chahiye.', done: true });
    return;
  }

  const inputs = { orderNumber, from, to };
  await chrome.storage.local.set({ inputs });
  chrome.runtime.sendMessage({ type: 'run', ...inputs });
  showStatus({ text: 'Shuru ho raha hai...', done: false });
});
