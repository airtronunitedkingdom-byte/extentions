# eBay Order Exporter

eBay UK Seller Hub ke orders ko CSV mein export karta hai.

## Install

1. Zip file extract karein.
2. Chrome mein `chrome://extensions` kholen.
3. Upar right side par **Developer mode** on karein.
4. **Load unpacked** par click karein aur extract kiya hua folder select karein.

## Use

1. Chrome mein eBay Seller Hub ka Orders page kholen (`ebay.co.uk/sh/ord`).
2. Orders list mein woh page dikhayen jis par aapka order number ho (list ka page size badha dein taake order wahan mojood ho).
3. Extension ka icon click karein.
4. **Order Number** likhein (zaroori).
5. **From date** aur **To date** optional hain. Dono khali chhodein to order number se latest tak sab export honge.
6. **Export CSV** dabayein. Har order ke liye background mein tab khul kar band hoga. Is dauran Chrome band na karein.

## Output

Column order wahi hai jo aapne diya: Sales record number, Order number, Post to name, Item title, Quantity, Sell Price, Buying, Order Earning, Sale date.

- **Sell Price**: Buyer ne jo amount di (discount ke baad).
- **Buying**: khali chhoda gaya hai, kyunki ye amount eBay ke order page par nahi hoti.
- **Sale date**: DD/MM/YYYY.

## Limitations

- Orders wahi export hote hain jo list ke current page par hain. Agar order kisi aur page par hai, to pehle us page par jayen.
- Agar eBay ka HTML badal jaye, to extension ke selectors theek karne padenge.
