const ids = ['kw', 'site', 'pages', 'maxSellers', 'topN', 'minFb', 'minPos', 'deep', 'verify', 'minSold', 'days', 'maxChecks', 'hideEmpty'];
const $ = id => document.getElementById(id);

chrome.storage.local.get('trsSettings', ({ trsSettings }) => {
  if (!trsSettings) return;
  ids.forEach(id => {
    if (trsSettings[id] === undefined) return;
    if ($(id).type === 'checkbox') $(id).checked = trsSettings[id];
    else $(id).value = trsSettings[id];
  });
});

function collect() {
  const s = {};
  ids.forEach(id => { s[id] = $(id).type === 'checkbox' ? $(id).checked : $(id).value; });
  return s;
}

$('go').addEventListener('click', () => {
  const s = collect();
  if (!s.kw.trim()) { $('kw').focus(); $('kw').style.borderColor = '#e0103a'; return; }
  chrome.storage.local.set({ trsSettings: s }, () => {
    const params = new URLSearchParams(s);
    chrome.tabs.create({ url: chrome.runtime.getURL('results.html') + '?' + params.toString() });
  });
});

$('fromTab').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const u = new URL(tab.url);
    if (!/ebay\./.test(u.hostname)) throw 0;
    const kw = u.searchParams.get('_nkw');
    if (kw) $('kw').value = kw;
    const opt = [...$('site').options].find(o => o.value === u.hostname);
    if (opt) $('site').value = u.hostname;
    if (!kw) $('kw').placeholder = 'Is page pe koi search keyword nahi mila';
  } catch (e) {
    $('kw').placeholder = 'Pehle eBay search page kholein';
  }
});
