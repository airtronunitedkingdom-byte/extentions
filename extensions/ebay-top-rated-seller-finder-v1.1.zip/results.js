const P = new URLSearchParams(location.search);
const cfg = {
  keywords: (P.get('kw') || '').split(',').map(s => s.trim()).filter(Boolean),
  host: P.get('site') || 'www.ebay.co.uk',
  pages: clamp(+P.get('pages') || 2, 1, 10),
  maxSellers: clamp(+P.get('maxSellers') || 20, 1, 200),
  topN: clamp(+P.get('topN') || 10, 1, 100),
  minFb: +P.get('minFb') || 0,
  minPos: +P.get('minPos') || 0,
  deep: P.get('deep') !== 'false',
  verify: P.get('verify') !== 'false',
  minSold: Math.max(1, +P.get('minSold') || 50),
  days: clamp(+P.get('days') || 30, 1, 90),
  maxChecks: clamp(+P.get('maxChecks') || 25, 1, 200),
  hideEmpty: P.get('hideEmpty') !== 'false'
};
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }

const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
let stopped = false;
let RESULTS = [];
const startedAt = new Date();

$('stop').onclick = () => { stopped = true; status('Stopped by user. Jo data mil chuka hai woh neeche hai.'); };
$('exportHtml').onclick = exportHtml;
$('exportCsv').onclick = exportCsv;
$('filter').oninput = applyFilter;

$('meta').textContent = `Keywords: ${cfg.keywords.join(', ')} · ${cfg.host} · ${cfg.pages} page(s) · max ${cfg.maxSellers} sellers · ${cfg.deep ? 'Deep scan' : 'Quick scan'}${cfg.verify ? ` · Shortlist: ≥${cfg.minSold} sold / last ${cfg.days} days` : ''}`;

function status(t, err) { $('status').textContent = t; $('status').className = err ? 'err' : ''; }
function progress(p) { $('bar').style.width = Math.round(p * 100) + '%'; }

const links = name => {
  const n = encodeURIComponent(name), h = cfg.host;
  return {
    profile: `https://${h}/usr/${n}`,
    store: `https://${h}/str/${n}`,
    items: `https://${h}/sch/i.html?_ssn=${n}&_ipg=240`,
    sold: `https://${h}/sch/i.html?_ssn=${n}&LH_Sold=1&LH_Complete=1&_ipg=240`,
    feedback: `https://${h}/fdbk/feedback_profile/${n}`
  };
};
const phUrl = id => `https://${cfg.host}/bin/purchaseHistory?item=${encodeURIComponent(id)}`;

async function getDoc(url) {
  await sleep(600 + Math.random() * 700); // be gentle with eBay
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  const html = await res.text();
  const doc = new DOMParser().parseFromString(html, 'text/html');
  if (TRSParser.isBlocked(doc, res.url)) {
    const e = new Error('BLOCKED'); e.blocked = true; throw e;
  }
  return doc;
}

async function run() {
  if (!cfg.keywords.length) { status('Koi keyword nahi diya gaya.', true); return; }
  const sellers = new Map();
  const totalSearch = cfg.keywords.length * cfg.pages;
  let done = 0;

  // 1) Search with eBay's "Top Rated Sellers" filter
  for (const kw of cfg.keywords) {
    for (let p = 1; p <= cfg.pages; p++) {
      if (stopped) break;
      status(`Searching "${kw}" – page ${p}/${cfg.pages}…`);
      const url = `https://${cfg.host}/sch/i.html?_nkw=${encodeURIComponent(kw)}&LH_TopRatedSellers=1&_ipg=240&_pgn=${p}`;
      let items = [];
      try { items = TRSParser.parseCards(await getDoc(url), cfg.host); }
      catch (e) { if (e.blocked) return blocked(); console.warn(e); }
      for (const it of items) {
        if (!it.seller) continue;
        const s = it.seller;
        if (!sellers.has(s.name)) sellers.set(s.name, { name: s.name, pct: s.pct, count: s.count, keywords: new Set(), searchItems: new Map() });
        const rec = sellers.get(s.name);
        rec.keywords.add(kw);
        rec.searchItems.set(it.id, it);
      }
      done++; progress(cfg.deep ? 0.25 * done / totalSearch : done / totalSearch);
      if (items.length < 50) break; // no more pages
    }
  }

  // 2) Filter + rank sellers
  let list = [...sellers.values()].filter(s => s.count >= cfg.minFb && s.pct >= cfg.minPos);
  list.forEach(s => {
    s.searchSold = [...s.searchItems.values()].reduce((a, b) => a + b.sold, 0);
    s.hits = s.searchItems.size;
  });
  list.sort((a, b) => (b.hits - a.hits) || (b.searchSold - a.searchSold) || (b.count - a.count));
  list = list.slice(0, cfg.maxSellers);

  if (!list.length) { status(`Koi Top Rated seller nahi mila (filters: min feedback ${cfg.minFb}, min ${cfg.minPos}%). Filters kam kar ke dobara try karein.`, true); progress(1); finishUI(); return; }

  RESULTS = list.map(s => ({ ...s, products: rankProducts([...s.searchItems.values()].map(i => ({ ...i, recent: 0 }))), activeCount: null, recentTotal: null }));
  render();

  // 3) Per seller: deep scan (optional) + purchase-history verification (optional)
  const work = cfg.deep || cfg.verify;
  if (work) {
    for (let i = 0; i < RESULTS.length; i++) {
      if (stopped) break;
      const s = RESULTS[i];
      try {
        if (cfg.deep) {
          status(`Seller ${i + 1}/${RESULTS.length}: ${s.name} – sold history…`);
          const L = links(s.name);
          const soldDoc = await getDoc(L.sold);
          const soldItems = TRSParser.parseCards(soldDoc, cfg.host);
          status(`Seller ${i + 1}/${RESULTS.length}: ${s.name} – active listings…`);
          const actDoc = await getDoc(L.items);
          const actItems = TRSParser.parseCards(actDoc, cfg.host);
          s.activeCount = TRSParser.resultCount(actDoc) ?? actItems.length;
          s.recentTotal = TRSParser.resultCount(soldDoc) ?? soldItems.length;
          s.candidates = mergeProducts(s, soldItems, actItems);
        } else {
          s.candidates = sortProducts([...s.searchItems.values()].map(it => ({ ...it, recent: 0 })));
        }
        s.products = s.candidates.slice(0, cfg.topN);
        if (cfg.verify) await verifySeller(s, i);
      } catch (e) {
        if (e.blocked) { render(); return blocked(); }
        console.warn(e);
      }
      progress(0.25 + 0.75 * (i + 1) / RESULTS.length);
      render();
    }
  }
  progress(1);
  const q = shortlist().length;
  status(stopped ? 'Stopped. Partial results neeche hain.'
    : cfg.verify
      ? `Done ✓ ${q} products shortlist hue (≥${cfg.minSold} sold, last ${cfg.days} days) – ${RESULTS.filter(s => s.qualified).length}/${RESULTS.length} sellers se. Ab "Export HTML" dabayein.`
      : `Done ✓ ${RESULTS.length} Top Rated sellers mile. Ab "Export HTML" dabayein.`);
  finishUI();
}

// ---------- Purchase-history verification ----------
const CACHE_KEY = 'phCache';
const CACHE_TTL = 6 * 3600e3; // 6 hours
let phCache = null;
async function loadCache() {
  if (phCache) return phCache;
  try {
    const o = await chrome.storage.local.get(CACHE_KEY);
    phCache = o[CACHE_KEY] || {};
    const now = Date.now();
    for (const k of Object.keys(phCache)) if (now - phCache[k].t > CACHE_TTL) delete phCache[k];
  } catch (e) { phCache = {}; }
  return phCache;
}
function saveCache() { try { chrome.storage.local.set({ [CACHE_KEY]: phCache }); } catch (e) { } }

async function checkItem(id) {
  const cache = await loadCache();
  const key = `${cfg.host}|${id}|${cfg.days}`;
  if (cache[key] && Date.now() - cache[key].t < CACHE_TTL) return cache[key];
  const doc = await getDoc(phUrl(id));
  const r = TRSParser.parsePurchaseHistory(doc, cfg.days);
  const rec = { t: Date.now(), qty: r.qty, orders: r.orders, rows: r.rows, truncated: r.truncated, lastPrice: r.lastPrice };
  cache[key] = rec; saveCache();
  return rec;
}

async function verifySeller(s, i) {
  // A listing showing fewer lifetime sales than the target can't reach it in X days – skip it to save requests.
  const pool = s.candidates.filter(p => !(p.sold > 0 && p.sold < cfg.minSold));
  const toCheck = pool.slice(0, cfg.maxChecks);
  s.checked = 0;
  for (let j = 0; j < toCheck.length; j++) {
    if (stopped) break;
    const p = toCheck[j];
    status(`Seller ${i + 1}/${RESULTS.length}: ${s.name} – purchase history ${j + 1}/${toCheck.length} (item ${p.id})…`);
    try {
      const r = await checkItem(p.id);
      p.sold30 = r.qty; p.orders30 = r.orders; p.phTruncated = r.truncated; p.checked = true;
      if (!p.price && r.lastPrice) p.price = r.lastPrice;
    } catch (e) {
      if (e.blocked) throw e;
      console.warn(e); p.checked = false;
    }
    s.checked++;
  }
  s.verified = true;
  const good = s.candidates.filter(p => p.checked && p.sold30 >= cfg.minSold)
    .sort((a, b) => (b.sold30 - a.sold30) || (b.sold - a.sold));
  s.qualified = good.length;
  s.products = good.slice(0, cfg.topN);
}

function shortlist() {
  const out = [];
  RESULTS.forEach(s => (s.candidates || s.products || []).forEach(p => { if (p.checked && p.sold30 >= cfg.minSold) out.push({ ...p, sellerName: s.name }); }));
  return out.sort((a, b) => b.sold30 - a.sold30);
}

const normTitle = t => t.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 80);

function mergeProducts(s, soldItems, actItems) {
  const map = new Map();
  const keyOf = it => it.id;
  const titleIdx = new Map();
  const add = (it, src) => {
    let k = keyOf(it);
    if (!map.has(k) && titleIdx.has(normTitle(it.title))) k = titleIdx.get(normTitle(it.title));
    if (!map.has(k)) {
      map.set(k, { ...it, recent: 0, sold: 0, lastSold: '' });
      titleIdx.set(normTitle(it.title), k);
    }
    const p = map.get(k);
    if (src === 'sold') {
      p.recent++;
      if (!p.lastSold && it.soldDate) p.lastSold = it.soldDate;
    } else {
      p.sold = Math.max(p.sold, it.sold || 0);
      p.price = it.price || p.price;
      p.image = p.image || it.image;
      p.id = it.id; p.url = it.url; // prefer live listing link
    }
  };
  soldItems.forEach(it => add(it, 'sold'));
  actItems.forEach(it => add(it, 'active'));
  for (const it of s.searchItems.values()) add(it, 'active');
  return sortProducts([...map.values()]);
}

function sortProducts(arr) {
  return arr.sort((a, b) => (b.recent - a.recent) || (b.sold - a.sold));
}
function rankProducts(arr) { return sortProducts(arr).slice(0, cfg.topN); }

function blocked() {
  status('eBay ne verification (captcha) ya sign-in maanga hai. Ek normal eBay tab mein captcha solve / sign in karein, thori der ruk kar yeh page refresh karein (checked items cache mein hain, dobara fetch nahi honge). Abhi tak ka data neeche hai.', true);
  finishUI();
}

function finishUI() {
  $('stop').disabled = true;
  $('exportHtml').disabled = !RESULTS.length;
  $('exportCsv').disabled = !RESULTS.length;
}

const fmt = n => (n === null || n === undefined) ? '–' : Number(n).toLocaleString('en-GB');
const sold30Cell = p => p.checked ? `<b>${fmt(p.sold30)}${p.phTruncated ? '+' : ''}</b>` : (cfg.verify ? '<span class="muted">not checked</span>' : '–');
const visibleSellers = () => RESULTS.filter(s => !(cfg.verify && cfg.hideEmpty && s.verified && !s.qualified));

function sellerSectionHtml(s, i) {
  const L = links(s.name);
  const emptyMsg = cfg.verify && s.verified
    ? `Koi product ≥${cfg.minSold} sold (last ${cfg.days} days) nahi mila – ${s.checked || 0} check kiye.`
    : 'No products found';
  const rows = s.products.length ? s.products.map((p, j) => `
    <tr>
      <td class="num">${j + 1}</td>
      <td>${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy">` : ''}</td>
      <td class="title"><a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title)}</a></td>
      <td>${esc(p.price)}</td>
      ${cfg.verify ? `<td class="num hl">${sold30Cell(p)}</td><td class="num">${p.checked ? fmt(p.orders30) : '–'}</td>` : ''}
      <td class="num">${p.recent ? fmt(p.recent) : '–'}</td>
      <td class="num">${p.sold ? fmt(p.sold) + '+' : '–'}</td>
      <td class="links"><a href="${esc(phUrl(p.id))}" target="_blank" rel="noopener">Purchase history</a></td>
    </tr>`).join('') : `<tr><td colspan="${cfg.verify ? 9 : 7}" class="empty">${esc(emptyMsg)}</td></tr>`;
  return `
  <div class="seller" data-search="${esc((s.name + ' ' + s.products.map(p => p.title).join(' ')).toLowerCase())}">
    <h3><span class="rank">${i + 1}</span><a href="${L.profile}" target="_blank" rel="noopener">${esc(s.name)}</a><span class="badge">TOP RATED</span>
      ${cfg.verify && s.verified ? `<span class="badge ${s.qualified ? '' : 'grey'}">${s.qualified || 0} winning products</span>` : ''}</h3>
    <div class="stats">
      Feedback <b>${fmt(s.count)}</b> · <b>${s.pct}%</b> positive ·
      Active listings <b>${fmt(s.activeCount)}</b> · Recent sales scanned <b>${fmt(s.recentTotal)}</b> ·
      ${cfg.verify && s.verified ? `Purchase history checked <b>${fmt(s.checked)}</b> ·` : ''}
      Keywords ${[...s.keywords].map(k => `<span class="kw">${esc(k)}</span>`).join('')}
    </div>
    <div class="links">
      <a href="${L.profile}" target="_blank" rel="noopener">Profile</a>
      <a href="${L.store}" target="_blank" rel="noopener">Store</a>
      <a href="${L.items}" target="_blank" rel="noopener">All items</a>
      <a href="${L.sold}" target="_blank" rel="noopener">Sold items</a>
      <a href="${L.feedback}" target="_blank" rel="noopener">Feedback</a>
    </div>
    <table style="margin-top:10px">
      <thead><tr><th class="num">#</th><th></th><th>Product</th><th>Price</th>
        ${cfg.verify ? `<th class="num">Sold ${cfg.days}d</th><th class="num">Orders ${cfg.days}d</th>` : ''}
        <th class="num">Recent sales</th><th class="num">Total sold</th><th>Check</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
}

function shortlistHtml() {
  if (!cfg.verify) return '';
  const list = shortlist();
  const rows = list.length ? list.map((p, j) => `
    <tr data-search="${esc((p.sellerName + ' ' + p.title).toLowerCase())}">
      <td class="num">${j + 1}</td>
      <td>${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy">` : ''}</td>
      <td class="title"><a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title)}</a></td>
      <td>${esc(p.price)}</td>
      <td class="num hl"><b>${fmt(p.sold30)}${p.phTruncated ? '+' : ''}</b></td>
      <td class="num">${fmt(p.orders30)}</td>
      <td><a href="${links(p.sellerName).profile}" target="_blank" rel="noopener">${esc(p.sellerName)}</a></td>
      <td class="links"><a href="${esc(phUrl(p.id))}" target="_blank" rel="noopener">Purchase history</a></td>
    </tr>`).join('') : `<tr><td colspan="8" class="empty">Abhi tak koi product ≥${cfg.minSold} sold (last ${cfg.days} days) nahi mila.</td></tr>`;
  return `
  <h2>Winning products shortlist <span class="muted" style="font-size:13px;font-weight:400">≥${cfg.minSold} sold · last ${cfg.days} days · ${list.length} products</span></h2>
  <table class="short">
    <thead><tr><th class="num">#</th><th></th><th>Product</th><th>Price</th><th class="num">Sold ${cfg.days}d</th><th class="num">Orders ${cfg.days}d</th><th>Seller</th><th>Check</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

function summaryRowsHtml() {
  return visibleSellers().map((s, i) => {
    const L = links(s.name), top = s.products[0];
    return `<tr data-search="${esc((s.name + ' ' + s.products.map(p => p.title).join(' ')).toLowerCase())}">
      <td class="num">${i + 1}</td>
      <td><a href="${L.profile}" target="_blank" rel="noopener"><b>${esc(s.name)}</b></a></td>
      <td class="num">${fmt(s.count)}</td>
      <td class="num">${s.pct}%</td>
      <td class="num">${fmt(s.activeCount)}</td>
      ${cfg.verify ? `<td class="num">${s.verified ? fmt(s.qualified) : '…'}</td>` : `<td class="num">${fmt(s.recentTotal)}</td>`}
      <td>${top ? `<a href="${esc(top.url)}" target="_blank" rel="noopener">${esc(top.title.slice(0, 70))}</a>${cfg.verify && top.checked ? ` <span class="muted">(${fmt(top.sold30)} sold)</span>` : ''}` : '–'}</td>
      <td class="links"><a href="${L.items}" target="_blank" rel="noopener">Items</a><a href="${L.sold}" target="_blank" rel="noopener">Sold</a></td>
    </tr>`;
  }).join('');
}
const summaryHead = () => `<tr><th>#</th><th>Seller</th><th>Feedback</th><th>Positive</th><th>Active listings</th><th>${cfg.verify ? `Winning products (≥${cfg.minSold}/${cfg.days}d)` : 'Recent sales (scanned)'}</th><th>Top product</th><th>Links</th></tr>`;

function render() {
  $('summary').hidden = false;
  $('shortlist').innerHTML = shortlistHtml();
  $('sumHead').innerHTML = summaryHead();
  $('sumBody').innerHTML = summaryRowsHtml();
  $('sellers').innerHTML = visibleSellers().map((s, i) => sellerSectionHtml(s, i)).join('');
  applyFilter();
}

function applyFilter() {
  const q = $('filter').value.toLowerCase().trim();
  document.querySelectorAll('[data-search]').forEach(el => {
    el.style.display = !q || el.dataset.search.includes(q) ? '' : 'none';
  });
}

function download(name, content, type) {
  const blob = new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

const fileStamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
const kwSlug = () => cfg.keywords.join('_').replace(/[^a-z0-9_]+/gi, '-').slice(0, 40);

async function exportHtml() {
  const css = await (await fetch('results.css')).text();
  const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>eBay Top Rated Sellers – ${esc(cfg.keywords.join(', '))}</title>
<style>${css} header{position:static}</style></head>
<body>
<header><div class="brand">eBay Top Rated Sellers Report</div>
<div class="meta">Keywords: <b>${esc(cfg.keywords.join(', '))}</b> · ${esc(cfg.host)} · Generated ${startedAt.toLocaleString('en-GB')} · ${visibleSellers().length} sellers${cfg.verify ? ` · ${shortlist().length} winning products (≥${cfg.minSold} sold / ${cfg.days} days)` : ''}</div></header>
<section>${shortlistHtml()}</section>
<section>
<h2>Top Rated Sellers</h2>
<input id="filter" placeholder="Filter sellers / products…" oninput="var q=this.value.toLowerCase();document.querySelectorAll('[data-search]').forEach(function(e){e.style.display=!q||e.dataset.search.indexOf(q)>-1?'':'none'})">
<table class="sum"><thead>${summaryHead()}</thead>
<tbody>${summaryRowsHtml()}</tbody></table>
</section>
<main>${visibleSellers().map((s, i) => sellerSectionHtml(s, i)).join('')}</main>
<section style="color:#777;font-size:12px">"Sold ${cfg.days}d" = eBay purchase history mein last ${cfg.days} din ki total quantity ("+" ka matlab eBay ne sirf recent rows dikhayin, asal number zyada ho sakta hai). "Recent sales" = seller ke recent sold listings mein yeh product kitni baar aaya. "Total sold" = listing par dikhaya gaya lifetime sold count.</section>
</body></html>`;
  download(`ebay-top-rated-sellers_${kwSlug()}_${fileStamp()}.html`, html, 'text/html');
}

function exportCsv() {
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [['Seller Rank', 'Seller', 'Feedback', 'Positive %', 'Active Listings', 'Seller Profile', 'Seller Items', 'Product Rank', 'Product', 'Price', `Sold Last ${cfg.days} Days`, `Orders Last ${cfg.days} Days`, 'Recent Sales', 'Total Sold', 'Last Sold', 'Product URL', 'Purchase History URL'].map(q).join(',')];
  visibleSellers().forEach((s, i) => {
    const L = links(s.name);
    (s.products.length ? s.products : [{}]).forEach((p, j) => {
      lines.push([i + 1, s.name, s.count, s.pct, s.activeCount ?? '', L.profile, L.items, p.title ? j + 1 : '', p.title, p.price, p.checked ? p.sold30 + (p.phTruncated ? '+' : '') : '', p.checked ? p.orders30 : '', p.recent || '', p.sold || '', p.lastSold || p.soldDate || '', p.url, p.id ? phUrl(p.id) : ''].map(q).join(','));
    });
  });
  download(`ebay-top-rated-sellers_${kwSlug()}_${fileStamp()}.csv`, '﻿' + lines.join('\r\n'), 'text/csv');
}

run().catch(e => { console.error(e); status('Error: ' + e.message, true); finishUI(); });
