eBay Top Rated Seller Finder - Chrome Extension
================================================

INSTALL
1. Zip ko extract karein (ek folder ban jayega).
2. Chrome mein chrome://extensions kholein.
3. Upar right mein "Developer mode" ON karein.
4. "Load unpacked" dabayein aur extracted folder select karein.
5. Toolbar mein extension pin kar lein.

USE
1. Icon par click karein, keyword(s) likhein (comma se multiple).
2. Settings: site, search pages, max sellers, products per seller, min feedback, min positive %.
3. "Find Top Rated Sellers" dabayein - naya tab khulega jahan progress aur results dikhenge.
4. Done hone par "Export HTML" (ya "Export CSV") dabayein.

KAISE KAAM KARTA HAI
- eBay search par "Top Rated Sellers" filter (LH_TopRatedSellers=1) laga kar sellers collect karta hai.
- Har seller ki recent SOLD listings aur active listings scan karke products rank karta hai:
  Recent sales (sold history mein kitni baar bika) -> phir Total sold (listing ka "X sold").
- Report mein seller profile, store, all items, sold items, feedback links hote hain.

NOTES
- Requests ke beech delay rakha gaya hai taake eBay block na kare. Agar captcha aaye,
  normal eBay tab mein solve karke results page refresh karein.
- "Recent sales" sirf scan kiye gaye sold-listings page (max 240) par based hai.

NAYA (v1.1) - 30 DIN KI SOLD SE SHORTLIST
- Popup mein "Purchase history se sold verify karein" ON rakhein.
- Har product ka https://www.ebay.co.uk/bin/purchaseHistory?item=ITEM_ID page khol kar
  last "Last days" (default 30) din ki Quantity jori jati hai.
- Sirf woh products shortlist hote hain jin ki sold >= "Min sold" (default 50).
- Results page ke top par "Winning products shortlist" table hai (sab sellers ke products, sold ke hisaab se).
- "Max checks/seller" = har seller ke kitne products check hon (zyada = zyada time + captcha ka risk).
- Jin listings ka lifetime "X sold" pehle se Min sold se kam hai, woh skip hoti hain (requests bachane ke liye).
- Check kiye gaye items 6 ghante cache mein rehte hain, refresh par dobara fetch nahi hote.
- "+" (jaise 60+) ka matlab: eBay ne sirf recent rows dikhayin aur sab 30 din ke andar thin - asal number zyada ho sakta hai.
- eBay mein sign in rehna behtar hai; captcha aaye to normal tab mein solve karke thori der baad refresh karein.
