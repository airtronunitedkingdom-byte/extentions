// Parsing helpers for eBay search result pages (supports new "s-card" and old "s-item" layouts).
const TRSParser = (() => {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();

  function parseNum(str) {
    if (!str) return 0;
    let s = String(str).trim().replace(/\+/g, '');
    let mult = 1;
    if (/k$/i.test(s)) { mult = 1000; s = s.slice(0, -1); }
    else if (/m$/i.test(s)) { mult = 1000000; s = s.slice(0, -1); }
    // "1,234" / "1.234" (thousands) vs "1.1" (decimal with K)
    if (mult === 1) s = s.replace(/[.,\s](?=\d{3}\b)/g, '');
    s = s.replace(',', '.');
    const n = parseFloat(s);
    return isNaN(n) ? 0 : Math.round(n * mult);
  }

  // Seller line, e.g. "rinish_co_uk 99.2% positive (1.1K)" or old "name (1,234) 99.5%"
  function parseSeller(card) {
    let rowEl = null;
    const rows = card.querySelectorAll('.s-card__attribute-row, .s-item__seller-info, .s-item__seller-info-text, .su-card-container__attributes__secondary div');
    for (const r of rows) { if (/\d\s*%/.test(r.textContent)) { rowEl = r; } }
    if (!rowEl) return null;
    const text = clean(rowEl.textContent);
    let name = '', pct = 0, count = 0, m;
    const spans = [...rowEl.querySelectorAll('span')].map(s => clean(s.textContent)).filter(Boolean);
    if ((m = text.match(/^(.+?)\s+([\d.,]+)\s*%[^()]*\(([\d.,]+\s*[KkMm]?)\)/))) {
      name = m[1]; pct = parseFloat(m[2].replace(',', '.')); count = parseNum(m[3]);
    } else if ((m = text.match(/^(.+?)\s*\(([\d.,]+\s*[KkMm]?)\)\s*([\d.,]+)\s*%/))) {
      name = m[1]; count = parseNum(m[2]); pct = parseFloat(m[3].replace(',', '.'));
    } else return null;
    if (spans.length && !/%/.test(spans[0]) && !/^\(/.test(spans[0])) name = spans[0];
    name = clean(name).replace(/\s*\(.*$/, '');
    if (!name || /\s/.test(name)) { // usernames have no spaces; take the last token before the %
      const t = name.split(' ');
      name = t[t.length - 1];
    }
    return { name, pct, count };
  }

  function parseCards(doc, host) {
    const out = [];
    const cards = doc.querySelectorAll('li.s-card[data-listingid], li.s-item');
    for (const c of cards) {
      const a = c.querySelector('a[href*="/itm/"]');
      if (!a) continue;
      const href = a.getAttribute('href') || '';
      const idm = href.match(/\/itm\/(?:[^/?]*\/)?(\d{9,})/);
      const id = c.dataset.listingid || (idm && idm[1]) || '';
      if (!id || id === '123456') continue;
      const titleEl = c.querySelector('.s-card__title, .s-item__title');
      let title = clean(titleEl ? titleEl.textContent : a.textContent)
        .replace(/Opens in a new window or tab/gi, '')
        .replace(/^New listing\s*/i, '').trim();
      if (!title || /^Shop on eBay$/i.test(title)) continue;
      const priceEl = c.querySelector('.s-card__price, .s-item__price');
      let price = '';
      if (priceEl) {
        const parts = [...c.querySelectorAll('.s-card__price')].map(e => clean(e.textContent));
        price = parts.length > 1 ? parts.join(' ') : clean(priceEl.textContent);
      }
      const img = c.querySelector('img');
      const image = img ? (img.getAttribute('src') || img.getAttribute('data-defer-load') || img.getAttribute('data-src') || '') : '';
      const text = clean(c.textContent);
      const soldM = text.match(/([\d.,]+\s*[KkMm]?)\+?\s+sold\b/i) || text.match(/([\d.,]+\s*[KkMm]?)\+?\s+(?:verkauft|vendus?|venduti|vendidos)\b/i);
      const sold = soldM ? parseNum(soldM[1]) : 0;
      const dateM = text.match(/Sold\s+(\d{1,2}\s+\w{3}\s+\d{4}|\w{3}\s+\d{1,2},\s*\d{4})/);
      const soldDate = dateM ? dateM[1] : '';
      out.push({
        id, title, price, image, sold, soldDate,
        url: `https://${host}/itm/${id}`,
        seller: parseSeller(c)
      });
    }
    return out;
  }

  function resultCount(doc) {
    const h = doc.querySelector('.srp-controls__count-heading, .result-count__count-heading');
    if (!h) return null;
    const m = clean(h.textContent).match(/([\d.,]+\+?)/);
    return m ? parseNum(m[1]) : null;
  }

  function isBlocked(doc, url) {
    if (/captcha|splashui|signin/i.test(url || '')) return true;
    const t = (doc.title || '') + ' ' + (doc.body ? doc.body.textContent.slice(0, 3000) : '');
    return /verify yourself|security measure|pardon our interruption|captcha/i.test(t);
  }

  // ---------- Purchase history (/bin/purchaseHistory?item=ID) ----------
  const MONTHS = {
    jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, sept: 8, oct: 9, nov: 10, dec: 11,
    mär: 2, mrz: 2, mai: 4, okt: 9, dez: 11, // de
    janv: 0, févr: 1, fevr: 1, mars: 2, avr: 3, juin: 5, juil: 6, août: 7, aout: 7, déc: 11, // fr
    gen: 0, mag: 4, giu: 5, lug: 6, ago: 7, set: 8, ott: 9, dic: 11, // it
    ene: 0, abr: 3 // es
  };
  const mon = s => {
    s = (s || '').toLowerCase().replace(/\./g, '');
    if (s in MONTHS) return MONTHS[s];
    const k = s.slice(0, 3);
    return k in MONTHS ? MONTHS[k] : -1;
  };
  const yr = y => { y = +y; return y < 100 ? 2000 + y : y; };
  function hm(h, mi, ap) {
    h = +h || 0; mi = +mi || 0;
    if (ap) { ap = ap.toLowerCase(); if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0; }
    return [h, mi];
  }

  // Returns a timestamp (ms) or null. Handles e.g.
  // "23 Nov 2026 at 5:34:25pm GMT", "Nov-23-26 17:34:25 PST", "Nov 23, 2026 5:34pm", "23.11.2026 17:34"
  function parseEbayDate(str) {
    const t = clean(str);
    let m, d;
    if ((m = t.match(/(\d{1,2})\.?\s+([A-Za-zÀ-ÿ]{3,})\.?\s+(\d{4})(?:\D+(\d{1,2}):(\d{2})(?::\d{2})?\s*(am|pm)?)?/i)) && mon(m[2]) >= 0) {
      const [h, mi] = hm(m[4], m[5], m[6]); d = new Date(yr(m[3]), mon(m[2]), +m[1], h, mi);
    } else if ((m = t.match(/([A-Za-z]{3,})[- ](\d{1,2})[-,]\s*(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*(am|pm)?)?/i)) && mon(m[1]) >= 0) {
      const [h, mi] = hm(m[4], m[5], m[6]); d = new Date(yr(m[3]), mon(m[1]), +m[2], h, mi);
    } else if ((m = t.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})(?:\D+(\d{1,2}):(\d{2}))?/))) {
      d = new Date(yr(m[3]), +m[2] - 1, +m[1], +m[4] || 0, +m[5] || 0); // dd.mm.yyyy
    } else return null;
    const ts = d.getTime();
    return isNaN(ts) ? null : ts;
  }

  // Sums quantity sold within the last `days` days from an eBay purchase-history page.
  function parsePurchaseHistory(doc, days) {
    const cutoff = Date.now() - days * 864e5;
    const res = { qty: 0, orders: 0, rows: 0, oldest: null, newest: null, lastPrice: '', noTable: false, truncated: false };
    const tables = [...doc.querySelectorAll('table')];
    const table = doc.querySelector('table.app-table__table') ||
      tables.find(t => t.rows[0] && /quantity|qty|menge|quantit|cantidad/i.test(t.rows[0].textContent));
    if (!table) { res.noTable = true; return res; }

    const head = [...(table.tHead ? table.tHead.rows[0] : table.rows[0]).cells].map(c => clean(c.textContent).toLowerCase());
    const find = re => head.findIndex(h => re.test(h));
    let qi = find(/quantity|qty|menge|quantit|cantidad/);
    let di = find(/date|datum|fecha|data/);
    const pi = find(/price|preis|prix|prezzo|precio/);

    const body = [...table.rows].filter(r => !r.querySelector('th') && r.cells.length > 1);
    for (const r of body) {
      const cells = [...r.cells].map(c => clean(c.textContent));
      let ts = di >= 0 ? parseEbayDate(cells[di]) : null;
      if (ts === null) { for (const c of cells) { ts = parseEbayDate(c); if (ts !== null) break; } }
      if (ts === null) continue;
      let q = qi >= 0 ? parseInt(cells[qi].replace(/\D/g, ''), 10) : 1;
      if (!q || q < 0) q = 1;
      res.rows++;
      if (res.oldest === null || ts < res.oldest) res.oldest = ts;
      if (res.newest === null || ts > res.newest) { res.newest = ts; if (pi >= 0) res.lastPrice = cells[pi]; }
      if (ts >= cutoff) { res.qty += q; res.orders++; }
    }
    // eBay shows a limited number of recent rows; if the list is long and even the oldest row is inside the window, the real number may be higher.
    res.truncated = res.rows >= 50 && res.oldest >= cutoff;
    return res;
  }

  return { parseCards, parseSeller, parseNum, resultCount, isBlocked, clean, parseEbayDate, parsePurchaseHistory };
})();
