// Pro Auto Refresher - Background Service Worker (Manifest V3)
// Made by MasoomDev

const ALARM_TICK = "pro_refresher_tick";

async function ensureTickerRunning() {
  const data = await chrome.storage.local.get("timers");
  const timers = data.timers || {};
  const activeCount = Object.keys(timers).length;

  if (activeCount > 0) {
    const existing = await chrome.alarms.get(ALARM_TICK);
    if (!existing) {
      chrome.alarms.create(ALARM_TICK, { periodInMinutes: 1 });
    }
    startPrecisionLoop();
  } else {
    await chrome.alarms.clear(ALARM_TICK);
    stopPrecisionLoop();
  }
}

let loopInterval = null;

function startPrecisionLoop() {
  if (loopInterval) return;
  loopInterval = setInterval(processTimers, 1000);
}

function stopPrecisionLoop() {
  if (loopInterval) {
    clearInterval(loopInterval);
    loopInterval = null;
  }
}

function computeNextDelay(config) {
  if (config.mode === "random") {
    const min = Math.max(1, Number(config.minSec) || 5);
    const max = Math.max(min, Number(config.maxSec) || 15);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  return Math.max(1, Number(config.intervalSec) || 10);
}

async function updateBadge(tabId, secondsLeft) {
  try {
    let text = "";
    if (secondsLeft >= 3600) {
      text = Math.floor(secondsLeft / 3600) + "h";
    } else if (secondsLeft >= 60) {
      text = Math.floor(secondsLeft / 60) + "m";
    } else if (secondsLeft > 0) {
      text = String(secondsLeft) + "s";
    } else {
      text = "...";
    }
    await chrome.action.setBadgeText({ tabId, text });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#2563eb" });
  } catch (e) {}
}

async function clearBadge(tabId) {
  try {
    await chrome.action.setBadgeText({ tabId, text: "" });
  } catch (e) {}
}

async function processTimers() {
  const data = await chrome.storage.local.get("timers");
  const timers = data.timers || {};
  const tabIds = Object.keys(timers);

  if (tabIds.length === 0) {
    stopPrecisionLoop();
    return;
  }

  let changed = false;

  for (const tabIdStr of tabIds) {
    const tabId = Number(tabIdStr);
    const timer = timers[tabIdStr];
    if (!timer || !timer.running) continue;

    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (e) {
      delete timers[tabIdStr];
      changed = true;
      continue;
    }

    timer.remaining -= 1;

    if (timer.remaining <= 0) {
      timer.reloadCount = (timer.reloadCount || 0) + 1;

      if (timer.maxReloads > 0 && timer.reloadCount > timer.maxReloads) {
        delete timers[tabIdStr];
        await clearBadge(tabId);
        changed = true;
        continue;
      }

      try {
        await chrome.tabs.reload(tabId, { bypassCache: Boolean(timer.hardReload) });
      } catch (e) {
        delete timers[tabIdStr];
        changed = true;
        continue;
      }

      timer.remaining = computeNextDelay(timer);
      changed = true;
      await updateBadge(tabId, timer.remaining);
    } else {
      changed = true;
      await updateBadge(tabId, timer.remaining);
    }
  }

  if (changed) {
    await chrome.storage.local.set({ timers });
  }
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;

  const data = await chrome.storage.local.get("timers");
  const timers = data.timers || {};
  const timer = timers[String(tabId)];
  if (!timer || !timer.running) return;

  if (timer.stopOnInteraction) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          if (window.__proRefresherBound) return;
          window.__proRefresherBound = true;
          const stopHandler = () => {
            chrome.runtime.sendMessage({ type: "USER_INTERACTED" });
          };
          window.addEventListener("mousedown", stopHandler, { once: true });
          window.addEventListener("keydown", stopHandler, { once: true });
        }
      });
    } catch (e) {}
  }

  if (timer.keyword && timer.keyword.trim() !== "") {
    const kw = timer.keyword.trim();
    const matchMode = timer.keywordMode || "found";

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: (searchWord) => {
          const bodyText = document.body ? document.body.innerText : "";
          return bodyText.toLowerCase().includes(searchWord.toLowerCase());
        },
        args: [kw]
      });

      const isPresent = results && results[0] && results[0].result;
      const triggered = (matchMode === "found" && isPresent) || (matchMode === "missing" && !isPresent);

      if (triggered) {
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: "Pro Auto Refresher Alert!",
          message: matchMode === "found"
            ? `Keyword "${kw}" was FOUND on ${tab.title || tab.url}`
            : `Keyword "${kw}" DISAPPEARED from ${tab.title || tab.url}`,
          priority: 2
        });

        if (timer.stopOnKeyword) {
          delete timers[String(tabId)];
          await chrome.storage.local.set({ timers });
          await clearBadge(tabId);
          await ensureTickerRunning();
        }
      }
    } catch (e) {}
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const data = await chrome.storage.local.get("timers");
  const timers = data.timers || {};
  if (timers[String(tabId)]) {
    delete timers[String(tabId)];
    await chrome.storage.local.set({ timers });
    await ensureTickerRunning();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    const data = await chrome.storage.local.get("timers");
    const timers = data.timers || {};

    if (msg.type === "START_TIMER") {
      const tabId = msg.tabId;
      const config = msg.config;
      const initialDelay = computeNextDelay(config);

      timers[String(tabId)] = {
        ...config,
        running: true,
        remaining: initialDelay,
        reloadCount: 0
      };

      await chrome.storage.local.set({ timers });
      await updateBadge(tabId, initialDelay);
      await ensureTickerRunning();
      sendResponse({ ok: true, timer: timers[String(tabId)] });
    }

    else if (msg.type === "STOP_TIMER") {
      const tabId = msg.tabId;
      delete timers[String(tabId)];
      await chrome.storage.local.set({ timers });
      await clearBadge(tabId);
      await ensureTickerRunning();
      sendResponse({ ok: true });
    }

    else if (msg.type === "STOP_ALL") {
      for (const idStr of Object.keys(timers)) {
        await clearBadge(Number(idStr));
      }
      await chrome.storage.local.set({ timers: {} });
      await ensureTickerRunning();
      sendResponse({ ok: true });
    }

    else if (msg.type === "USER_INTERACTED" && sender.tab) {
      const tabId = sender.tab.id;
      if (timers[String(tabId)] && timers[String(tabId)].stopOnInteraction) {
        delete timers[String(tabId)];
        await chrome.storage.local.set({ timers });
        await clearBadge(tabId);
        await ensureTickerRunning();
      }
      sendResponse({ ok: true });
    }

    else if (msg.type === "GET_STATUS") {
      const tabId = msg.tabId;
      sendResponse({
        timer: timers[String(tabId)] || null,
        activeCount: Object.keys(timers).length
      });
    }
  })();

  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_TICK) {
    ensureTickerRunning();
  }
});

chrome.runtime.onStartup.addListener(ensureTickerRunning);
chrome.runtime.onInstalled.addListener(ensureTickerRunning);
