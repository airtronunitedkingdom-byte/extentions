// Pro Auto Refresher - Popup Controller
// Made by MasoomDev

document.addEventListener("DOMContentLoaded", async () => {
  let currentTabId = null;
  let currentMode = "fixed";
  let uiPollInterval = null;

  const tabFixed = document.getElementById("tabFixed");
  const tabRandom = document.getElementById("tabRandom");
  const fixedSection = document.getElementById("fixedSection");
  const randomSection = document.getElementById("randomSection");

  const presetBtns = document.querySelectorAll(".preset-btn");
  const customHours = document.getElementById("customHours");
  const customMinutes = document.getElementById("customMinutes");
  const customSeconds = document.getElementById("customSeconds");

  const minSeconds = document.getElementById("minSeconds");
  const maxSeconds = document.getElementById("maxSeconds");

  const hardReload = document.getElementById("hardReload");
  const stopOnInteraction = document.getElementById("stopOnInteraction");
  const maxReloads = document.getElementById("maxReloads");

  const keywordInput = document.getElementById("keywordInput");
  const keywordMode = document.getElementById("keywordMode");
  const stopOnKeyword = document.getElementById("stopOnKeyword");

  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const stopAllBtn = document.getElementById("stopAllBtn");

  const statusPill = document.getElementById("statusPill");
  const activeTabsBadge = document.getElementById("activeTabsBadge");
  const countdownCard = document.getElementById("countdownCard");
  const countdownDisplay = document.getElementById("countdownDisplay");
  const reloadCounterDisplay = document.getElementById("reloadCounterDisplay");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  currentTabId = tab.id;

  const saved = await chrome.storage.local.get("lastConfig");
  if (saved.lastConfig) {
    applyConfigToUI(saved.lastConfig);
  }

  function setMode(mode) {
    currentMode = mode;
    if (mode === "fixed") {
      tabFixed.classList.add("active");
      tabRandom.classList.remove("active");
      fixedSection.classList.remove("hidden");
      randomSection.classList.add("hidden");
    } else {
      tabRandom.classList.add("active");
      tabFixed.classList.remove("active");
      randomSection.classList.remove("hidden");
      fixedSection.classList.add("hidden");
    }
  }

  tabFixed.addEventListener("click", () => setMode("fixed"));
  tabRandom.addEventListener("click", () => setMode("random"));

  presetBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      presetBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const totalSec = Number(btn.dataset.sec);
      const hrs = Math.floor(totalSec / 3600);
      const mins = Math.floor((totalSec % 3600) / 60);
      const secs = totalSec % 60;
      customHours.value = hrs;
      customMinutes.value = mins;
      customSeconds.value = secs;
    });
  });

  [customHours, customMinutes, customSeconds].forEach((inp) => {
    inp.addEventListener("input", () => {
      presetBtns.forEach((b) => b.classList.remove("active"));
    });
  });

  function formatTime(sec) {
    const s = Math.max(0, Number(sec) || 0);
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const remSec = s % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return hrs > 0 ? `${pad(hrs)}:${pad(mins)}:${pad(remSec)}` : `${pad(mins)}:${pad(remSec)}`;
  }

  function buildConfigFromUI() {
    const hrs = Math.max(0, Number(customHours.value) || 0);
    const mins = Math.max(0, Number(customMinutes.value) || 0);
    const secs = Math.max(0, Number(customSeconds.value) || 0);
    let intervalSec = hrs * 3600 + mins * 60 + secs;
    if (intervalSec < 1) intervalSec = 1;

    const minS = Math.max(1, Number(minSeconds.value) || 5);
    const maxS = Math.max(minS, Number(maxSeconds.value) || 15);

    return {
      mode: currentMode,
      intervalSec,
      minSec: minS,
      maxSec: maxS,
      hardReload: hardReload.checked,
      stopOnInteraction: stopOnInteraction.checked,
      maxReloads: Math.max(0, Number(maxReloads.value) || 0),
      keyword: keywordInput.value.trim(),
      keywordMode: keywordMode.value,
      stopOnKeyword: stopOnKeyword.checked
    };
  }

  function applyConfigToUI(cfg) {
    if (!cfg) return;
    setMode(cfg.mode || "fixed");

    const totalSec = cfg.intervalSec || 10;
    customHours.value = Math.floor(totalSec / 3600);
    customMinutes.value = Math.floor((totalSec % 3600) / 60);
    customSeconds.value = totalSec % 60;

    presetBtns.forEach((b) => {
      b.classList.toggle("active", Number(b.dataset.sec) === totalSec);
    });

    minSeconds.value = cfg.minSec || 5;
    maxSeconds.value = cfg.maxSec || 20;
    hardReload.checked = Boolean(cfg.hardReload);
    stopOnInteraction.checked = Boolean(cfg.stopOnInteraction);
    maxReloads.value = cfg.maxReloads || 0;
    keywordInput.value = cfg.keyword || "";
    keywordMode.value = cfg.keywordMode || "found";
    stopOnKeyword.checked = cfg.stopOnKeyword !== undefined ? cfg.stopOnKeyword : true;
  }

  function updateStatusUI(timer, activeCount) {
    activeTabsBadge.textContent = `${activeCount} active tab${activeCount === 1 ? "" : "s"}`;

    if (activeCount > 0) {
      stopAllBtn.classList.remove("hidden");
    } else {
      stopAllBtn.classList.add("hidden");
    }

    if (timer && timer.running) {
      statusPill.textContent = "RUNNING";
      statusPill.classList.add("active");
      countdownCard.classList.remove("hidden");
      countdownDisplay.textContent = formatTime(timer.remaining);
      const limitText = timer.maxReloads > 0 ? ` / ${timer.maxReloads}` : "";
      reloadCounterDisplay.textContent = `Reloads completed: ${timer.reloadCount || 0}${limitText}`;

      startBtn.textContent = "Update Settings";
      stopBtn.classList.remove("hidden");
    } else {
      statusPill.textContent = "IDLE";
      statusPill.classList.remove("active");
      countdownCard.classList.add("hidden");
      startBtn.textContent = "Start Auto Refresh";
      stopBtn.classList.add("hidden");
    }
  }

  async function refreshStatus() {
    chrome.runtime.sendMessage({ type: "GET_STATUS", tabId: currentTabId }, (res) => {
      if (res) {
        updateStatusUI(res.timer, res.activeCount);
      }
    });
  }

  chrome.runtime.sendMessage({ type: "GET_STATUS", tabId: currentTabId }, (res) => {
    if (res) {
      if (res.timer) applyConfigToUI(res.timer);
      updateStatusUI(res.timer, res.activeCount);
    }
  });

  uiPollInterval = setInterval(refreshStatus, 500);

  startBtn.addEventListener("click", async () => {
    const config = buildConfigFromUI();
    await chrome.storage.local.set({ lastConfig: config });

    chrome.runtime.sendMessage({ type: "START_TIMER", tabId: currentTabId, config }, (res) => {
      if (res && res.ok) {
        refreshStatus();
      }
    });
  });

  stopBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "STOP_TIMER", tabId: currentTabId }, () => {
      refreshStatus();
    });
  });

  stopAllBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "STOP_ALL" }, () => {
      refreshStatus();
    });
  });
});
