eBay Growth Report - Chrome Extension (v2.0.0, Phase 2: Recommendations + Tracking)

INSTALL
1. Unzip this folder somewhere permanent (don't delete it later).
2. Open Chrome -> chrome://extensions
3. Turn on "Developer mode" (top right).
4. Click "Load unpacked" and select the unzipped folder.
5. Pin the extension (puzzle icon -> pin).

USE
1. Sign in to eBay UK (ebay.co.uk) in Chrome.
2. Click the extension icon -> the generator page opens.
3. (Optional) Load your previous report HTML so revision status / plan log carry over.
4. Click "Generate report". It takes about 1 minute for ~400 listings.
5. The report downloads as ebay-growth-report-YYYY-MM-DD.html and also opens in a new tab.

PHASE 2 (in the report)
- Page 2 "Recommendations & tracking" builds a 30-day plan: max 10 listings revised per day
  (change it in Plan settings), 7-day cooldown, re-check after 7 days.
- Each listing shows what to change and why; tick actions as you finish them.
- Ticking a task done marks that listing "Revised" on page 1.
- IMPORTANT: progress lives inside the HTML file. Click "Save HTML (with tracking)" after
  working. The page shows "unsaved changes" until you do. Keep the saved file and load it
  as the previous report next time so the plan carries over.
- Use "Export JSON" / "Import JSON" for a backup of the tracking data.

NOTES
- Read-only: it only reads your Seller Hub data, it never edits listings.
- It uses the same internal Seller Hub endpoints as the Traffic and Active listings pages.
  If eBay changes those pages, the extension may need an update.
