window.addEventListener('message', e => {
  if (!e.data || e.data.type !== 'egr-render') return;
  document.open(); document.write(e.data.html); document.close();
});
