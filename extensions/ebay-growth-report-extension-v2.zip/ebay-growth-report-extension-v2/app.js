/* eBay Growth Report – generator page logic */
const $ = id => document.getElementById(id);
const logEl = $('log');
let prevReport = null; // {state, data}

function log(msg, cls) {
  const t = new Date().toLocaleTimeString('en-GB');
  const line = document.createElement('div');
  line.textContent = `[${t}] ${msg}`;
  if (cls) line.className = cls;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}
function progress(p) { $('prog').style.width = Math.max(0, Math.min(100, p)) + '%'; }

// Progress messages sent from the collector running inside the eBay tab
chrome.runtime.onMessage.addListener(m => {
  if (m && m.type === 'egr-progress') { log(m.msg); if (m.p != null) progress(m.p); }
});

/* ---------- previous report (optional) ---------- */
$('prevFile').addEventListener('change', async e => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    const doc = new DOMParser().parseFromString(await f.text(), 'text/html');
    const st = doc.getElementById('plan-state'), dt = doc.getElementById('listing-data');
    if (!st || !dt) throw new Error('This file is not an eBay Growth Report (data blocks missing).');
    prevReport = { state: JSON.parse(st.textContent), data: JSON.parse(dt.textContent) };
    const rev = prevReport.data.filter(r => r.revised).length;
    $('prevInfo').innerHTML = `<span class="ok">✔ Loaded:</span> snapshot ${prevReport.state.snapshotDate}, ${prevReport.data.length} listings, ${rev} revised, phase ${prevReport.state.currentPhase}.`;
    $('clearPrev').style.display = '';
  } catch (err) {
    prevReport = null;
    $('prevInfo').innerHTML = `<span class="err">✖ ${err.message}</span>`;
  }
});
$('clearPrev').onclick = () => { prevReport = null; $('prevFile').value = ''; $('prevInfo').textContent = ''; $('clearPrev').style.display = 'none'; };

/* ---------- find or open an eBay UK tab ---------- */
async function getEbayTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.ebay.co.uk/*' });
  if (tabs.length) return tabs.find(t => t.url.includes('/sh/')) || tabs[0];
  log('No eBay tab found – opening Seller Hub…');
  const tab = await chrome.tabs.create({ url: 'https://www.ebay.co.uk/sh/ovw', active: false });
  await new Promise(res => {
    const fn = (id, info) => { if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(fn); res(); } };
    chrome.tabs.onUpdated.addListener(fn);
  });
  return tab;
}

/* ---------- collector: runs INSIDE the eBay tab (uses your eBay login) ---------- */
async function collectEbayData() {
  const say = (msg, p) => { try { chrome.runtime.sendMessage({ type: 'egr-progress', msg, p }); } catch (e) {} };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = new Date();
  const end = ymd(today) + 'T23:59:59Z';

  async function trafficFor(days, pBase) {
    const s = new Date(today); s.setDate(s.getDate() - (days - 1));
    const start = ymd(s) + 'T00:00:00+00:00';
    let cursor = null, out = [], page = 0;
    while (true) {
      const pag = { maxPageSize: 200 };
      if (cursor) pag.pageCursor = cursor;
      const vars = {
        listingsInput: { filters: { marketplaces: ['EBAY_GB'], searchKeyword: null }, sort: { field: 'AVAILABLE_QUANTITY', sortOrder: 'DESC' }, pagination: pag },
        trafficInput: { dateTimeRange: { startDateTime: start, endDateTime: end } },
        metricsInput: { dateTimeRange: { startDateTime: start, endDateTime: end }, include: [{ listingSiteIDs: [3] }], exclude: null }
      };
      const res = await fetch('/sh/performance/graphql?op=TrafficListings&vars=' + encodeURIComponent(JSON.stringify(vars)), { credentials: 'include' });
      const txt = await res.text();
      let j;
      try { j = JSON.parse(txt); } catch (e) { throw new Error('eBay did not return data – are you signed in to Seller Hub?'); }
      if (!j.data || !j.data.sellerListingSearch) throw new Error('Traffic request failed: ' + JSON.stringify(j).slice(0, 200));
      const al = j.data.sellerListingSearch.activeListings;
      for (const x of al.listings) {
        const L = x.listing || {}, m = L.listingTrafficPerformanceMetrics || {};
        out.push({
          id: x.listingId, t: (L.sellerProduct || {}).title || '', q: L.totalQuantity || 0,
          imp: +m.totalImpressions || 0, v: +m.totalEbayViews || 0,
          sold: +(((L.salesMetrics || {}).sales || {}).totalTransactionSoldQuantity) || 0
        });
      }
      page++;
      const total = (al.pagination && al.pagination.totalElements) || out.length;
      say(`Traffic ${days} days: ${out.length} / ${total} listings`, pBase + 20 * Math.min(1, out.length / Math.max(1, total)));
      cursor = al.pagination && al.pagination.nextCursor;
      if (!cursor || page > 50) break;
      await sleep(400);
    }
    return out;
  }

  const t14 = await trafficFor(14, 0);
  const t30 = await trafficFor(30, 20);
  const t90 = await trafficFor(90, 40);

  // Active listings page: list date, price, watchers, promoted, best offer
  const meta = {};
  const want = new Set(t30.map(x => x.id));
  for (let off = 0; off < 10000; off += 200) {
    const html = await fetch(`/sh/lst/active?limit=200&offset=${off}`, { credentials: 'include' }).then(r => r.text());
    let found = 0;
    for (const c of html.split('{"entityId":"').slice(1)) {
      const id = c.slice(0, c.indexOf('"'));
      const g = k => { const m = c.match(new RegExp('"' + k + '":("?)([^",}]*)\\1')); return m ? m[2] : null; };
      const sd = g('listingStartDate');
      if (!sd) continue;
      meta[id] = Object.assign(meta[id] || {}, { sd, cat: g('categoryId'), promo: g('promoted') === 'true', bo: g('hasBestOffer') === 'true' });
    }
    const doc = new DOMParser().parseFromString(html, 'text/html');
    for (const r of doc.querySelectorAll('tr.grid-row[data-id]')) {
      const id = r.getAttribute('data-id');
      const cell = n => { const e = r.querySelector('.shui-dt-column__' + n); return e ? e.textContent.replace(/\s+/g, ' ').trim() : ''; };
      const m = meta[id] = meta[id] || {};
      m.watch = parseInt(cell('watchCount').replace(/[^\d]/g, '')) || 0;
      m.views = parseInt((cell('visitCount').match(/^[\d,]+/) || ['0'])[0].replace(/,/g, '')) || 0;
      m.price = cell('price').replace(/Buy It Now|Research prices|Auction/g, '').replace(/or Best Offer/g, '').trim();
      found++;
    }
    const have = [...want].filter(id => meta[id] && meta[id].sd).length;
    say(`Active listings page (offset ${off}): ${have} / ${want.size} list dates found`, 60 + 35 * have / Math.max(1, want.size));
    if (found < 200 || have >= want.size) break;
    await sleep(500);
  }
  return { t14, t30, t90, meta, snapshot: ymd(today) };
}

/* ---------- build report ---------- */
function buildRows(raw) {
  const by = arr => Object.fromEntries(arr.map(x => [x.id, x]));
  const a = by(raw.t14), b = by(raw.t30), c = by(raw.t90);
  const ids = [...new Set([...raw.t90, ...raw.t30, ...raw.t14].map(x => x.id))];
  let noDate = 0;
  const rows = ids.map(id => {
    const base = b[id] || c[id] || a[id], m = raw.meta[id] || {};
    const z = { imp: 0, v: 0, sold: 0 };
    const A = a[id] || z, B = b[id] || z, C = c[id] || z;
    if (!m.sd) noDate++;
    return {
      id, t: base.t, q: base.q,
      i14: A.imp, v14: A.v, s14: A.sold, i30: B.imp, v30: B.v, s30: B.sold, i90: C.imp, v90: C.v, s90: C.sold,
      ld: (m.sd || raw.snapshot).slice(0, 10), p: m.price || '', cat: m.cat || '', pr: m.promo ? 1 : 0,
      w: m.watch || 0, lv: m.views || 0, bo: m.bo ? 1 : 0, revised: false, revisedOn: null
    };
  });
  if (noDate) log(`⚠ ${noDate} listings had no list date on the Active listings page (shown as today).`, 'err');
  return rows;
}

function buildState(rows, snapshot) {
  const gen = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  if (prevReport) {
    const st = JSON.parse(JSON.stringify(prevReport.state));
    st.snapshotDate = snapshot; st.generatedAt = gen;
    st.log = st.log || [];
    st.log.push({ date: snapshot, phase: st.currentPhase, action: 'Data refreshed by extension', listings: rows.length });
    return st;
  }
  return {
    account: 'discount_paradize', site: 'UK (ebay.co.uk)', snapshotDate: snapshot, generatedAt: gen, currentPhase: 2,
    phases: [
      { n: 1, name: 'Phase 1 · Listing analysis', status: 'done', date: snapshot },
      { n: 2, name: 'Phase 2 · Recommendations + tracking (10/day, 30-day plan)', status: 'current' },
      { n: 3, name: 'Phase 3 · Re-measure', status: 'next' }
    ],
    notes: `Phase 1 baseline: all ${rows.length} active listings analysed (14/30/90-day impressions, views, sold). Phase 2 plan: max 10 revisions/day over 30 days, tracked in this file. Click "Save HTML (with tracking)" to keep progress.`,
    log: [{ date: snapshot, phase: 1, action: 'Baseline analysis report created (extension)', listings: rows.length }]
  };
}

function mergePrevious(rows) {
  if (!prevReport) return rows;
  const fresh = new Set(Object.keys(rows[0] || {}));
  const old = Object.fromEntries(prevReport.data.map(r => [r.id, r]));
  let carried = 0;
  rows.forEach(r => {
    const o = old[r.id]; if (!o) return;
    r.revised = !!o.revised; r.revisedOn = o.revisedOn || null;
    for (const k of Object.keys(o)) if (!fresh.has(k)) r[k] = o[k]; // keep future tracking fields
    carried++;
  });
  const gone = prevReport.data.filter(o => !rows.some(r => r.id === o.id)).length;
  log(`Merged previous report: ${carried} listings matched, ${gone} no longer active.`);
  return rows;
}

async function makeHtml(rows, state) {
  const tpl = await fetch(chrome.runtime.getURL('report-template.html')).then(r => r.text());
  const safe = s => s.replace(/<\//g, '<\\/');
  return tpl.replace('__STATE__', () => safe(JSON.stringify(state))).replace('__DATA__', () => safe(JSON.stringify(rows)));
}

$('go').onclick = async () => {
  $('go').disabled = true; logEl.textContent = ''; progress(0); $('status').textContent = 'Working…';
  try {
    const tab = await getEbayTab();
    log(`Using eBay tab: ${tab.url}`);
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectEbayData });
    if (!res || !res.result) throw new Error('No data returned from the eBay tab.');
    const raw = res.result;
    let rows = buildRows(raw);
    rows = mergePrevious(rows);
    const state = buildState(rows, raw.snapshot);
    const html = await makeHtml(rows, state);
    const sum = k => rows.reduce((a, r) => a + r[k], 0);
    log(`Totals 30d → impressions ${sum('i30').toLocaleString()}, views ${sum('v30').toLocaleString()}, sold ${sum('s30')}`);
    const name = `ebay-growth-report-${raw.snapshot}.html`;
    if ($('optDownload').checked) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      a.download = name; a.click();
      log(`Downloaded ${name}`);
    }
    if ($('optOpen').checked) {
      await chrome.storage.local.set({ lastReport: html, lastReportName: name });
      await chrome.tabs.create({ url: chrome.runtime.getURL('report.html') });
    }
    progress(100);
    $('status').innerHTML = `<span class="ok">✔ Report ready – ${rows.length} listings</span>`;
    log('Done.', 'ok');
  } catch (err) {
    $('status').innerHTML = `<span class="err">✖ ${err.message}</span>`;
    log('Error: ' + (err && err.message || err), 'err');
  } finally {
    $('go').disabled = false;
  }
};
