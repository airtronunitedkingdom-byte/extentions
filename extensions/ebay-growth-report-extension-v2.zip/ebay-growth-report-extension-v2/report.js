// Shows the last generated report inside a sandboxed frame (needed because extension pages block inline scripts).
const frame = document.getElementById('v');
frame.addEventListener('load', async () => {
  const { lastReport, lastReportName } = await chrome.storage.local.get(['lastReport', 'lastReportName']);
  if (lastReportName) document.title = lastReportName.replace('.html', '');
  frame.contentWindow.postMessage({ type: 'egr-render', html: lastReport || '<h2 style="font-family:sans-serif;padding:30px">No report generated yet.</h2>' }, '*');
});
